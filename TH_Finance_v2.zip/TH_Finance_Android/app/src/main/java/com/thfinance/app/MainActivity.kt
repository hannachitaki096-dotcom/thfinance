package com.thfinance.app

import android.app.Activity
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.compose.foundation.isSystemInDarkTheme
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.time.LocalDate
import java.time.YearMonth
import java.util.Locale

@Entity(tableName = "transactions")
data class Tx(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val month: String,
    val kind: String, // expense, bill, income, transfer, debt, saving
    val category: String,
    val note: String,
    val amount: Double,
    val account: String,
    val date: String = LocalDate.now().toString()
)

@Entity(tableName = "monthly_settings", primaryKeys = ["month"])
data class MonthSettings(
    val month: String,
    val salary: Double = 0.0,
    val cashOpening: Double = 0.0,
    val bankOpening: Double = 0.0,
    val savingsGoal: Double = 0.0,
    @ColumnInfo(defaultValue = "0") val absences: Int = 0,
    @ColumnInfo(defaultValue = "26") val workDays: Int = 26
)

@Dao
interface FinanceDao {
    @Query("SELECT * FROM transactions WHERE month = :month ORDER BY date DESC, id DESC")
    fun transactions(month: String): kotlinx.coroutines.flow.Flow<List<Tx>>

    @Query("SELECT * FROM monthly_settings WHERE month = :month")
    fun settings(month: String): kotlinx.coroutines.flow.Flow<MonthSettings?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: MonthSettings)

    @Insert
    suspend fun add(tx: Tx)

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun delete(id: Long)
}

@Database(entities = [Tx::class, MonthSettings::class], version = 2, exportSchema = false)
abstract class FinanceDb : RoomDatabase() {
    abstract fun dao(): FinanceDao
    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE monthly_settings ADD COLUMN absences INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE monthly_settings ADD COLUMN workDays INTEGER NOT NULL DEFAULT 26")
            }
        }
        @Volatile private var INSTANCE: FinanceDb? = null
        fun get(context: android.content.Context) = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, FinanceDb::class.java, "th_finance.db").addMigrations(MIGRATION_1_2).build().also { INSTANCE = it }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = FinanceDb.get(this).dao()
        setContent { FinanceApp(dao) }
    }
}

private val ink = Color(0xFF173B35)
private val mint = Color(0xFFDAEEE5)
private val orange = Color(0xFFE6A23C)
private val bg = Color(0xFFF5F7F6)
private fun money(v: Double) = NumberFormat.getNumberInstance(Locale("fr", "DZ")).format(v) + " دج"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinanceApp(dao: FinanceDao) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var month by remember { mutableStateOf(YearMonth.now()) }
    val key = month.toString()
    val txs by dao.transactions(key).collectAsState(initial = emptyList())
    val settings by dao.settings(key).collectAsState(initial = null)
    var salary by remember(key, settings) { mutableStateOf(settings?.salary?.takeIf { it > 0 }?.toString() ?: "") }
    var cash by remember(key, settings) { mutableStateOf(settings?.cashOpening?.takeIf { it > 0 }?.toString() ?: "") }
    var bank by remember(key, settings) { mutableStateOf(settings?.bankOpening?.takeIf { it > 0 }?.toString() ?: "") }
    var goal by remember(key, settings) { mutableStateOf(settings?.savingsGoal?.takeIf { it > 0 }?.toString() ?: "") }
    var workDays by remember(key, settings) { mutableStateOf((settings?.workDays ?: 26).toString()) }
    var absences by remember(key, settings) { mutableStateOf((settings?.absences ?: 0).toString()) }
    val systemDark = isSystemInDarkTheme()
    val prefs = remember { context.getSharedPreferences("th_prefs", android.content.Context.MODE_PRIVATE) }
    var dark by remember { mutableStateOf(if (prefs.contains("dark")) prefs.getBoolean("dark", false) else systemDark) }
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var kind by remember { mutableStateOf("expense") }
    var category by remember { mutableStateOf("مشتريات") }
    var note by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var account by remember { mutableStateOf("نقدًا") }
    var debtType by remember { mutableStateOf("دين عليّ") }

    val expenses = txs.filter { it.kind == "expense" || it.kind == "bill" }
    val spent = expenses.sumOf { it.amount }
    val income = txs.filter { it.kind == "income" }.sumOf { it.amount }
    val saved = txs.filter { it.kind == "saving" }.sumOf { it.amount }
    val cashTransfersIn = txs.filter { it.kind == "transfer" && it.category == "من البنك" }.sumOf { it.amount }
    val cashTransfersOut = txs.filter { it.kind == "transfer" && it.category == "من نقدًا" }.sumOf { it.amount }
    val bankTransfersIn = txs.filter { it.kind == "transfer" && it.category == "من نقدًا" }.sumOf { it.amount }
    val bankTransfersOut = txs.filter { it.kind == "transfer" && it.category == "من البنك" }.sumOf { it.amount }
    val cashSpent = expenses.filter { it.account == "نقدًا" }.sumOf { it.amount }
    val bankSpent = expenses.filter { it.account == "البنك" }.sumOf { it.amount }
    val cashBalance = (cash.toDoubleOrNull() ?: 0.0) + cashTransfersIn - cashTransfersOut - cashSpent +
        txs.filter { it.kind == "income" && it.account == "نقدًا" }.sumOf { it.amount }
    val bankBalance = (bank.toDoubleOrNull() ?: 0.0) + bankTransfersIn - bankTransfersOut - bankSpent +
        txs.filter { it.kind == "income" && it.account == "البنك" }.sumOf { it.amount }
    val totalAvailable = cashBalance + bankBalance
    val debts = txs.filter { it.kind == "debt" }
    val baseSalary = salary.toDoubleOrNull() ?: settings?.salary ?: 0.0
    val wd = (workDays.toIntOrNull() ?: 26).coerceAtLeast(1)
    val ab = (absences.toIntOrNull() ?: 0).coerceIn(0, wd)
    val dailyWage = baseSalary / wd
    val deduction = dailyWage * ab
    val netSalary = baseSalary - deduction
    val monthIncome = netSalary + income
    val fmt = remember { NumberFormat.getNumberInstance(Locale("fr", "DZ")) }
    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { output ->
                    val doc = PdfDocument()
                    val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
                    val page = doc.startPage(pageInfo)
                    val paint = Paint().apply { textSize = 18f; color = android.graphics.Color.BLACK }
                    var y = 55f
                    fun line(text: String, size: Float = 18f) {
                        paint.textSize = size
                        page.canvas.drawText(text, 40f, y, paint)
                        y += size + 13f
                    }
                    line("TH Finance - Monthly report", 22f)
                    line("Month: $key", 15f)
                    line("Salary: ${salary.toDoubleOrNull() ?: settings?.salary ?: 0.0} DZD", 14f)
                    line("Absence days: $ab of $wd work days", 14f)
                    line("Salary deduction: $deduction DZD", 14f)
                    line("Net salary: $netSalary DZD", 14f)
                    line("Opening cash: ${cash.toDoubleOrNull() ?: settings?.cashOpening ?: 0.0} DZD", 14f)
                    line("Opening bank: ${bank.toDoubleOrNull() ?: settings?.bankOpening ?: 0.0} DZD", 14f)
                    line("Total expenses: ${expenses.sumOf { it.amount }} DZD", 14f)
                    line("Transactions:", 17f)
                    txs.forEach { tx ->
                        if (y > 790f) return@forEach
                        line("${tx.date} | ${tx.kind} | ${tx.note} | ${tx.amount} DZD", 10f)
                    }
                    doc.finishPage(page)
                    doc.writeTo(output)
                    doc.close()
                }
            }
        }
    }

    val colors = if (dark) darkColorScheme(
        primary = Color(0xFF7FD1B9), onPrimary = Color(0xFF0B2520), secondary = orange,
        background = Color(0xFF101514), surface = Color(0xFF1B2220), primaryContainer = Color(0xFF1F4D44)
    ) else lightColorScheme(
        primary = ink, secondary = orange, background = bg, surface = Color.White, primaryContainer = ink
    )
    MaterialTheme(colorScheme = colors) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = { Column { Text("TH Finance", fontWeight = FontWeight.Bold); Text("إدارة أموالك بذكاء", fontSize = 12.sp) } },
                    actions = {
                        IconButton(onClick = { dark = !dark; prefs.edit().putBoolean("dark", dark).apply() }) {
                            Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, "الوضع الليلي")
                        }
                        IconButton(onClick = { tab = 4 }) { Icon(Icons.Default.BarChart, "الإحصائيات") }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }, containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary) {
                    Icon(Icons.Default.Add, "إضافة")
                }
            },
            bottomBar = {
                NavigationBar {
                    listOf("الرئيسية", "الحركات", "الميزانية", "الديون", "إحصائيات").forEachIndexed { i, label ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i },
                            icon = { Icon(listOf(Icons.Default.Home, Icons.Default.ReceiptLong, Icons.Default.AccountBalanceWallet, Icons.Default.Handshake, Icons.Default.PieChart)[i], null) },
                            label = { Text(label, fontSize = 10.sp) })
                    }
                }
            }
        ) { padding ->
            when (tab) {
                0 -> HomeScreen(month, { month = month.minusMonths(1) }, { month = month.plusMonths(1) },
                    cashBalance, bankBalance, totalAvailable, monthIncome, spent, goal.toDoubleOrNull() ?: settings?.savingsGoal ?: 0.0,
                    txs.take(5), onDelete = { id -> scope.launch { dao.delete(id) } }, netSalary = netSalary, absences = ab, modifier = Modifier.padding(padding))
                1 -> TransactionsScreen(txs, onDelete = { id -> scope.launch { dao.delete(id) } }, modifier = Modifier.padding(padding))
                2 -> BudgetScreen(salary, { salary = it }, cash, { cash = it }, bank, { bank = it }, goal, { goal = it },
                    workDays = workDays, onWorkDays = { workDays = it }, absences = absences, onAbsences = { absences = it },
                    dailyWage = dailyWage, deduction = deduction, netSalary = netSalary,
                    onSave = { scope.launch { dao.saveSettings(MonthSettings(key, salary.toDoubleOrNull() ?: 0.0, cash.toDoubleOrNull() ?: 0.0, bank.toDoubleOrNull() ?: 0.0, goal.toDoubleOrNull() ?: 0.0, ab, wd)) } },
                    modifier = Modifier.padding(padding))
                3 -> DebtsScreen(debts, onDelete = { id -> scope.launch { dao.delete(id) } }, modifier = Modifier.padding(padding))
                else -> StatsScreen(expenses, spent, monthIncome, saved, onExport = { pdfLauncher.launch("TH_Finance_$key.pdf") }, modifier = Modifier.padding(padding))
            }
        }
    }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("إضافة حركة مالية") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    var expanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                        OutlinedTextField(value = when(kind) { "expense" -> "مصروف / مشتريات"; "bill" -> "فاتورة"; "income" -> "دخل إضافي"; "transfer" -> "تحويل بين الحسابات"; "debt" -> "دين"; else -> "ادخار" },
                            onValueChange = {}, readOnly = true, label = { Text("نوع الحركة") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            listOf("مصروف / مشتريات" to "expense", "فاتورة" to "bill", "دخل إضافي" to "income", "تحويل بين الحسابات" to "transfer", "دين" to "debt", "ادخار" to "saving").forEach { (l,v) ->
                                DropdownMenuItem(text = { Text(l) }, onClick = { kind = v; category = if(v=="bill") "فواتير" else if(v=="transfer") "من نقدًا" else if(v=="debt") debtType else "مشتريات"; expanded = false })
                            }
                        }
                    }
                    OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("الوصف / الجهة") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = amount, onValueChange = { amount = it }, label = { Text("المبلغ بالدينار") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                    if (kind == "transfer") {
                        Text("اتجاه التحويل")
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(selected = category == "من نقدًا", onClick = { category = "من نقدًا" }, label = { Text("نقدًا ← بنك") })
                            FilterChip(selected = category == "من البنك", onClick = { category = "من البنك" }, label = { Text("بنك ← نقدًا") })
                        }
                    } else if (kind == "debt") {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(selected = category == "دين عليّ", onClick = { category = "دين عليّ" }, label = { Text("دين عليّ") })
                            FilterChip(selected = category == "لي عند الغير", onClick = { category = "لي عند الغير" }, label = { Text("لي عند الغير") })
                        }
                    }
                    Text("الحساب")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = account == "نقدًا", onClick = { account = "نقدًا" }, label = { Text("نقدًا") })
                        FilterChip(selected = account == "البنك", onClick = { account = "البنك" }, label = { Text("البنك") })
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val v = amount.toDoubleOrNull()
                    if (v != null && v > 0) {
                        scope.launch {
                            val finalCategory = if (kind == "transfer") category else if(kind=="debt") category else if(kind=="bill") "فواتير" else if(kind=="saving") "ادخار" else if(kind=="income") "دخل إضافي" else "مشتريات"
                            dao.add(Tx(month = key, kind = kind, category = finalCategory, note = note.ifBlank { finalCategory }, amount = v, account = account))
                        }
                        amount = ""; note = ""; showAdd = false
                    }
                }) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun Header(text: String) { Text(text, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) }

@Composable
fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Text(title, color = Color.Gray, fontSize = 12.sp)
            Text(value, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
fun HomeScreen(month: YearMonth, prev: () -> Unit, next: () -> Unit, cash: Double, bank: Double, total: Double,
               income: Double, spent: Double, goal: Double, recent: List<Tx>, onDelete: (Long)->Unit, netSalary: Double = 0.0, absences: Int = 0, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("إجمالي أموالك المتاحة", color = mint)
                    Text(money(total), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column { Text("نقدًا", color = mint, fontSize = 12.sp); Text(money(cash), color = Color.White, fontWeight = FontWeight.SemiBold) }
                        Column { Text("في البنك", color = mint, fontSize = 12.sp); Text(money(bank), color = Color.White, fontWeight = FontWeight.SemiBold) }
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                IconButton(onClick = prev) { Icon(Icons.Default.ChevronLeft, "الشهر السابق") }
                Text(month.toString(), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                IconButton(onClick = next) { Icon(Icons.Default.ChevronRight, "الشهر التالي") }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("الدخل الشهري", money(income), Icons.Default.TrendingUp, Modifier.weight(1f))
                StatCard("المصاريف", money(spent), Icons.Default.TrendingDown, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("الراتب الصافي", money(netSalary), Icons.Default.Payments, Modifier.weight(1f))
                StatCard("أيام الغياب", "$absences يوم", Icons.Default.EventBusy, Modifier.weight(1f))
            }
        }
        item { Header("آخر الحركات") }
        if (recent.isEmpty()) item { Text("لا توجد حركات بعد. اضغط + لإضافة أول حركة.", color = Color.Gray) }
        items(recent) { tx -> TransactionRow(tx, onDelete) }
    }
}

@Composable
fun TransactionRow(tx: Tx, onDelete: (Long)->Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tx.note, fontWeight = FontWeight.SemiBold)
                Text("${tx.category} • ${tx.date}", fontSize = 11.sp, color = Color.Gray)
            }
            Text(money(tx.amount), fontWeight = FontWeight.Bold, color = if(tx.kind=="income") Color(0xFF16834D) else MaterialTheme.colorScheme.primary, fontSize = 13.sp)
            IconButton(onClick = { onDelete(tx.id) }) { Icon(Icons.Default.DeleteOutline, null, tint = Color.Gray) }
        }
    }
}

@Composable
fun TransactionsScreen(txs: List<Tx>, onDelete: (Long)->Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), contentPadding = PaddingValues(bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Header("سجل الحركات") }
        if(txs.isEmpty()) item { Text("سجل المصاريف والدخل والتحويلات والادخار من زر +") }
        items(txs) { TransactionRow(it, onDelete) }
    }
}

@Composable
fun BudgetScreen(salary: String, onSalary: (String)->Unit, cash: String, onCash: (String)->Unit, bank: String, onBank: (String)->Unit,
                 goal: String, onGoal: (String)->Unit,
                 workDays: String, onWorkDays: (String)->Unit, absences: String, onAbsences: (String)->Unit,
                 dailyWage: Double, deduction: Double, netSalary: Double,
                 onSave: ()->Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), contentPadding = PaddingValues(bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Header("الميزانية والأرصدة الافتتاحية") }
        item { Text("أدخل القيم الخاصة بالشهر الحالي. يمكنك تعديلها في أي وقت.", color = Color.Gray, fontSize = 12.sp) }
        item { MoneyField("الراتب الشهري", salary, onSalary) }
        item { MoneyField("أيام العمل في الشهر", workDays, onWorkDays) }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                FilledTonalIconButton(onClick = { onAbsences(((absences.toIntOrNull() ?: 0) - 1).coerceAtLeast(0).toString()) }) { Icon(Icons.Default.Remove, "نقص") }
                OutlinedTextField(value = absences, onValueChange = onAbsences, label = { Text("عدد أيام الغياب") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                FilledTonalIconButton(onClick = { onAbsences(((absences.toIntOrNull() ?: 0) + 1).toString()) }) { Icon(Icons.Default.Add, "زيادة") }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("حساب الراتب", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text("أجر اليوم: ${money(dailyWage)}", fontSize = 13.sp)
                    Text("خصم الغياب: ${money(deduction)}", fontSize = 13.sp)
                    Text("الراتب الصافي: ${money(netSalary)}", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
        item { MoneyField("النقدية الموجودة بداية الشهر", cash, onCash) }
        item { MoneyField("رصيد البنك بداية الشهر", bank, onBank) }
        item { MoneyField("هدف الادخار الشهري", goal, onGoal) }
        item { Button(onClick = onSave, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("حفظ الميزانية") } }
    }
}

@Composable
fun MoneyField(label: String, value: String, onChange: (String)->Unit) {
    OutlinedTextField(value = value, onValueChange = onChange, label = { Text(label) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(), singleLine = true)
}

@Composable
fun DebtsScreen(debts: List<Tx>, onDelete: (Long)->Unit, modifier: Modifier = Modifier) {
    val owed = debts.filter { it.category == "دين عليّ" }.sumOf { it.amount }
    val receivable = debts.filter { it.category == "لي عند الغير" }.sumOf { it.amount }
    LazyColumn(modifier.fillMaxSize().padding(16.dp), contentPadding = PaddingValues(bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Header("الديون والمستحقات") }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("ديون عليك", money(owed), Icons.Default.ArrowUpward, Modifier.weight(1f))
            StatCard("ديون لك", money(receivable), Icons.Default.ArrowDownward, Modifier.weight(1f))
        } }
        item { Text("أضف دينًا من زر +، وحدد هل هو دين عليك أم مبلغ لك عند شخص آخر.", color = Color.Gray, fontSize = 12.sp) }
        items(debts) { TransactionRow(it, onDelete) }
    }
}

@Composable
fun StatsScreen(expenses: List<Tx>, spent: Double, income: Double, saved: Double, onExport: () -> Unit, modifier: Modifier = Modifier) {
    val purchases = expenses.filter { it.category == "مشتريات" }.sumOf { it.amount }
    val bills = expenses.filter { it.category == "فواتير" }.sumOf { it.amount }
    val primaryC = MaterialTheme.colorScheme.primary
    LazyColumn(modifier.fillMaxSize().padding(16.dp), contentPadding = PaddingValues(bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Header("الإحصائيات الشهرية") }
        item { OutlinedButton(onClick = onExport, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.width(8.dp)); Text("تصدير تقرير PDF") } }
        item { StatCard("إجمالي المصاريف", money(spent), Icons.Default.Receipt, Modifier.fillMaxWidth()) }
        item { StatCard("الدخل", money(income), Icons.Default.AccountBalance, Modifier.fillMaxWidth()) }
        item { StatCard("الادخار المسجل", money(saved), Icons.Default.Savings, Modifier.fillMaxWidth()) }
        item { Header("توزيع المصاريف") }
        item {
            if(spent <= 0) Text("أضف مصاريف لعرض الرسم البياني.", color = Color.Gray)
            else {
                Canvas(Modifier.fillMaxWidth().height(190.dp)) {
                    val total = (purchases + bills).coerceAtLeast(1.0)
                    val p = purchases / total
                    drawArc(primaryC, -90f, (360f*p).toFloat(), false, style = Stroke(width = 34.dp.toPx()))
                    drawArc(orange, -90f + (360f*p).toFloat(), (360f*(1-p)).toFloat(), false, style = Stroke(width = 34.dp.toPx()))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    Text("● المشتريات ${money(purchases)}", color = primaryC, fontSize = 12.sp)
                    Text("● الفواتير ${money(bills)}", color = orange, fontSize = 12.sp)
                }
            }
        }
    }
}
