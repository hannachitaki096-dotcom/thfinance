package com.thfinance.app

import android.app.Activity
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.compose.foundation.isSystemInDarkTheme
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.time.LocalDate
import java.time.YearMonth
import java.util.Locale

@Entity(tableName = "transactions")
data class Tx(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val month: String,
    val kind: String, // expense, bill, income, transfer, debt, saving
    val category: String,
    val note: String,
    val amount: Double,
    val account: String,
    val date: String = LocalDate.now().toString()
)

@Entity(tableName = "monthly_settings", primaryKeys = ["month"])
data class MonthSettings(
    val month: String,
    val salary: Double = 0.0,
    val cashOpening: Double = 0.0,
    val bankOpening: Double = 0.0,
    val savingsGoal: Double = 0.0,
    @ColumnInfo(defaultValue = "0") val absences: Int = 0,
    @ColumnInfo(defaultValue = "26") val workDays: Int = 26
)

@Dao
interface FinanceDao {
    @Query("SELECT * FROM transactions WHERE month = :month ORDER BY date DESC, id DESC")
    fun transactions(month: String): kotlinx.coroutines.flow.Flow<List<Tx>>

    @Query("SELECT * FROM monthly_settings WHERE month = :month")
    fun settings(month: String): kotlinx.coroutines.flow.Flow<MonthSettings?>

    @Query("SELECT * FROM transactions")
    fun allTransactions(): kotlinx.coroutines.flow.Flow<List<Tx>>

    @Query("SELECT * FROM monthly_settings ORDER BY month ASC")
    fun allSettings(): kotlinx.coroutines.flow.Flow<List<MonthSettings>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: MonthSettings)

    @Insert
    suspend fun add(tx: Tx)

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun delete(id: Long)
}

@Database(entities = [Tx::class, MonthSettings::class], version = 2, exportSchema = false)
abstract class FinanceDb : RoomDatabase() {
    abstract fun dao(): FinanceDao
    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE monthly_settings ADD COLUMN absences INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE monthly_settings ADD COLUMN workDays INTEGER NOT NULL DEFAULT 26")
            }
        }
        @Volatile private var INSTANCE: FinanceDb? = null
        fun get(context: android.content.Context) = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, FinanceDb::class.java, "th_finance.db").addMigrations(MIGRATION_1_2).build().also { INSTANCE = it }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = FinanceDb.get(this).dao()
        appLang.value = getSharedPreferences("th_prefs", android.content.Context.MODE_PRIVATE).getString("lang", "ar") ?: "ar"
        setContent { FinanceApp(dao) }
    }
}

private val ink = Color(0xFF173B35)
private val mint = Color(0xFFDAEEE5)
private val orange = Color(0xFFE6A23C)
private val bg = Color(0xFFF5F7F6)
private val appLang = mutableStateOf("ar")
private val EN = mapOf(
    "إدارة أموالك بذكاء" to "Manage your money smartly", "الوضع الليلي" to "Dark mode", "الإحصائيات" to "Statistics", "إضافة" to "Add",
    "الرئيسية" to "Home", "الحركات" to "Transactions", "الميزانية" to "Budget", "الديون" to "Debts", "إحصائيات" to "Stats",
    "إضافة حركة مالية" to "Add transaction", "مصروف / مشتريات" to "Expense / Purchases", "فاتورة" to "Bill", "دخل إضافي" to "Extra income",
    "تحويل بين الحسابات" to "Transfer between accounts", "دين" to "Debt", "ادخار" to "Saving", "نوع الحركة" to "Transaction type",
    "اسم صاحب الدين / المدين" to "Name of creditor / debtor", "الوصف / الجهة" to "Description / Party", "المبلغ بالدينار" to "Amount (DZD)",
    "اتجاه التحويل" to "Transfer direction", "نقدًا ← بنك" to "Cash → Bank", "بنك ← نقدًا" to "Bank → Cash",
    "دين عليّ" to "I owe", "لي عند الغير" to "Owed to me", "الحساب" to "Account", "نقدًا" to "Cash", "البنك" to "Bank",
    "حفظ" to "Save", "إلغاء" to "Cancel", "إجمالي أموالك المتاحة" to "Total available funds", "في البنك" to "In bank",
    "الشهر السابق" to "Previous month", "الشهر التالي" to "Next month", "الدخل الشهري" to "Monthly income", "المصاريف" to "Expenses",
    "الراتب الصافي" to "Net salary", "أيام الغياب" to "Absence days", "يوم" to "days", "آخر الحركات" to "Recent transactions",
    "لا توجد حركات بعد. اضغط + لإضافة أول حركة." to "No transactions yet. Tap + to add your first one.",
    "سجل الحركات" to "Transaction log", "سجل المصاريف والدخل والتحويلات والادخار من زر +" to "Record expenses, income, transfers and savings with the + button",
    "الميزانية والأرصدة الافتتاحية" to "Budget and opening balances",
    "أدخل القيم الخاصة بالشهر الحالي. يمكنك تعديلها في أي وقت." to "Enter this month's values. You can edit them anytime.",
    "الراتب الشهري" to "Monthly salary", "أيام العمل في الشهر" to "Work days in the month", "نقص" to "Decrease",
    "عدد أيام الغياب" to "Number of absence days", "زيادة" to "Increase", "حساب الراتب" to "Salary calculation",
    "أجر اليوم" to "Daily wage", "خصم الغياب" to "Absence deduction",
    "المتبقي من الشهر السابق (يُرحَّل تلقائياً)" to "Left over from last month (carried over automatically)",
    "المتبقي من الشهر السابق (مُضاف تلقائياً)" to "Left over from last month (added automatically)",
    "النقدية الموجودة بداية الشهر" to "Cash at start of month", "رصيد البنك بداية الشهر" to "Bank balance at start of month",
    "هدف الادخار الشهري" to "Monthly savings goal", "حفظ الميزانية" to "Save budget",
    "الديون والمستحقات" to "Debts and receivables", "ديون عليك" to "You owe", "ديون لك" to "Owed to you",
    "أضف دينًا من زر +، واكتب اسم صاحب الدين أو المدين، وحدد هل هو دين عليك أم مبلغ لك عند شخص آخر." to "Add a debt with the + button, write the creditor or debtor name, and choose whether you owe it or it is owed to you.",
    "حسب الشخص" to "By person", "لك" to "Owed to you", "عليك" to "You owe", "مسدّد" to "Settled", "سجل الديون" to "Debt log",
    "مشتريات" to "Purchases", "فواتير" to "Bills", "الإحصائيات الشهرية" to "Monthly statistics", "تصدير تقرير PDF" to "Export PDF report",
    "إجمالي المصاريف" to "Total expenses", "الدخل" to "Income", "الادخار المسجل" to "Recorded savings", "توزيع المصاريف" to "Expense breakdown",
    "أضف مصاريف لعرض الرسم البياني." to "Add expenses to see the chart.", "دج" to "DZD", "من البنك" to "From bank", "من نقدًا" to "From cash",
    "حركة الأموال الشهرية" to "Monthly money flow", "رصيد البداية" to "Opening balance", "رصيد النهاية" to "Closing balance",
    "الادخار" to "Savings", "لا توجد بيانات شهرية بعد. احفظ الميزانية أولاً." to "No monthly data yet. Save a budget first."
)
private fun t(ar: String): String = if (appLang.value == "en") (EN[ar] ?: ar) else ar
private fun money(v: Double) = NumberFormat.getNumberInstance(Locale("fr", "DZ")).format(v) + " " + t("دج")

private fun cashDelta(t: List<Tx>): Double =
    t.filter { it.kind == "transfer" && it.category == "من البنك" }.sumOf { it.amount } -
    t.filter { it.kind == "transfer" && it.category == "من نقدًا" }.sumOf { it.amount } -
    t.filter { (it.kind == "expense" || it.kind == "bill") && it.account == "نقدًا" }.sumOf { it.amount } +
    t.filter { it.kind == "income" && it.account == "نقدًا" }.sumOf { it.amount }

private fun bankDelta(t: List<Tx>): Double =
    t.filter { it.kind == "transfer" && it.category == "من نقدًا" }.sumOf { it.amount } -
    t.filter { it.kind == "transfer" && it.category == "من البنك" }.sumOf { it.amount } -
    t.filter { (it.kind == "expense" || it.kind == "bill") && it.account == "البنك" }.sumOf { it.amount } +
    t.filter { it.kind == "income" && it.account == "البنك" }.sumOf { it.amount }

data class MonthRow(val month: String, val income: Double, val spent: Double, val saved: Double, val openTotal: Double, val closeTotal: Double)

private fun buildMonthly(allSettings: List<MonthSettings>, allTxs: List<Tx>): List<MonthRow> {
    val first = allSettings.firstOrNull() ?: return emptyList()
    val byMonth = allTxs.groupBy { it.month }
    val last = (allTxs.map { it.month } + allSettings.map { it.month } + YearMonth.now().toString()).max()
    var ym = YearMonth.parse(first.month)
    val end = YearMonth.parse(last)
    var cash = first.cashOpening
    var bank = first.bankOpening
    val rows = ArrayList<MonthRow>()
    while (ym <= end) {
        val m = ym.toString()
        val list = byMonth[m] ?: emptyList()
        val own = allSettings.firstOrNull { it.month == m }
        val ref = own ?: allSettings.lastOrNull { it.month < m } ?: first
        val wd = ref.workDays.coerceAtLeast(1)
        val ab = (own?.absences ?: 0).coerceIn(0, wd)
        val net = ref.salary - ref.salary / wd * ab
        val open = cash + bank
        cash += cashDelta(list)
        bank += bankDelta(list)
        rows.add(MonthRow(
            m,
            net + list.filter { it.kind == "income" }.sumOf { it.amount },
            list.filter { it.kind == "expense" || it.kind == "bill" }.sumOf { it.amount },
            list.filter { it.kind == "saving" }.sumOf { it.amount },
            open, cash + bank
        ))
        ym = ym.plusMonths(1)
    }
    return rows.reversed()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinanceApp(dao: FinanceDao) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var month by remember { mutableStateOf(YearMonth.now()) }
    val key = month.toString()
    val txs by dao.transactions(key).collectAsState(initial = emptyList())
    val settings by dao.settings(key).collectAsState(initial = null)
    val allTxs by dao.allTransactions().collectAsState(initial = emptyList())
    val allSettings by dao.allSettings().collectAsState(initial = emptyList())
    val prevSettings = allSettings.lastOrNull { it.month < key }
    var salary by remember(key, settings, prevSettings) { mutableStateOf((settings?.salary ?: prevSettings?.salary)?.takeIf { it > 0 }?.toString() ?: "") }
    var cash by remember(key, settings) { mutableStateOf(settings?.cashOpening?.takeIf { it > 0 }?.toString() ?: "") }
    var bank by remember(key, settings) { mutableStateOf(settings?.bankOpening?.takeIf { it > 0 }?.toString() ?: "") }
    var goal by remember(key, settings, prevSettings) { mutableStateOf((settings?.savingsGoal ?: prevSettings?.savingsGoal)?.takeIf { it > 0 }?.toString() ?: "") }
    var workDays by remember(key, settings, prevSettings) { mutableStateOf((settings?.workDays ?: prevSettings?.workDays ?: 26).toString()) }
    var absences by remember(key, settings) { mutableStateOf((settings?.absences ?: 0).toString()) }
    val systemDark = isSystemInDarkTheme()
    val prefs = remember { context.getSharedPreferences("th_prefs", android.content.Context.MODE_PRIVATE) }
    var dark by remember { mutableStateOf(if (prefs.contains("dark")) prefs.getBoolean("dark", false) else systemDark) }
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var kind by remember { mutableStateOf("expense") }
    var category by remember { mutableStateOf("مشتريات") }
    var note by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var account by remember { mutableStateOf("نقدًا") }
    var debtType by remember { mutableStateOf("دين عليّ") }

    val expenses = txs.filter { it.kind == "expense" || it.kind == "bill" }
    val spent = expenses.sumOf { it.amount }
    val income = txs.filter { it.kind == "income" }.sumOf { it.amount }
    val saved = txs.filter { it.kind == "saving" }.sumOf { it.amount }
    val cashTransfersIn = txs.filter { it.kind == "transfer" && it.category == "من البنك" }.sumOf { it.amount }
    val cashTransfersOut = txs.filter { it.kind == "transfer" && it.category == "من نقدًا" }.sumOf { it.amount }
    val bankTransfersIn = txs.filter { it.kind == "transfer" && it.category == "من نقدًا" }.sumOf { it.amount }
    val bankTransfersOut = txs.filter { it.kind == "transfer" && it.category == "من البنك" }.sumOf { it.amount }
    val cashSpent = expenses.filter { it.account == "نقدًا" }.sumOf { it.amount }
    val bankSpent = expenses.filter { it.account == "البنك" }.sumOf { it.amount }
    val firstSettings = allSettings.firstOrNull()
    val autoOpening = firstSettings != null && month > YearMonth.parse(firstSettings.month)
    var carriedCash = 0.0
    var carriedBank = 0.0
    if (firstSettings != null && autoOpening) {
        carriedCash = firstSettings.cashOpening
        carriedBank = firstSettings.bankOpening
        val byMonth = allTxs.groupBy { it.month }
        var ym = YearMonth.parse(firstSettings.month)
        while (ym < month) {
            val list = byMonth[ym.toString()] ?: emptyList()
            carriedCash += cashDelta(list)
            carriedBank += bankDelta(list)
            ym = ym.plusMonths(1)
        }
    }
    val openCash = if (autoOpening) carriedCash else (cash.toDoubleOrNull() ?: 0.0)
    val openBank = if (autoOpening) carriedBank else (bank.toDoubleOrNull() ?: 0.0)
    val cashBalance = openCash + cashTransfersIn - cashTransfersOut - cashSpent +
        txs.filter { it.kind == "income" && it.account == "نقدًا" }.sumOf { it.amount }
    val bankBalance = openBank + bankTransfersIn - bankTransfersOut - bankSpent +
        txs.filter { it.kind == "income" && it.account == "البنك" }.sumOf { it.amount }
    val totalAvailable = cashBalance + bankBalance
    val debts = allTxs.filter { it.kind == "debt" }.sortedWith(compareByDescending<Tx> { it.date }.thenByDescending { it.id })
    val baseSalary = salary.toDoubleOrNull() ?: settings?.salary ?: 0.0
    val wd = (workDays.toIntOrNull() ?: 26).coerceAtLeast(1)
    val ab = (absences.toIntOrNull() ?: 0).coerceIn(0, wd)
    val dailyWage = baseSalary / wd
    val deduction = dailyWage * ab
    val netSalary = baseSalary - deduction
    val monthIncome = netSalary + income
    val fmt = remember { NumberFormat.getNumberInstance(Locale("fr", "DZ")) }
    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { output ->
                    val doc = PdfDocument()
                    val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
                    val page = doc.startPage(pageInfo)
                    val paint = Paint().apply { textSize = 18f; color = android.graphics.Color.BLACK }
                    var y = 55f
                    fun line(text: String, size: Float = 18f) {
                        paint.textSize = size
                        page.canvas.drawText(text, 40f, y, paint)
                        y += size + 13f
                    }
                    line("TH Finance - Monthly report", 22f)
                    line("Month: $key", 15f)
                    line("Salary: ${salary.toDoubleOrNull() ?: settings?.salary ?: 0.0} DZD", 14f)
                    line("Absence days: $ab of $wd work days", 14f)
                    line("Salary deduction: $deduction DZD", 14f)
                    line("Net salary: $netSalary DZD", 14f)
                    line("Opening cash: $openCash DZD", 14f)
                    line("Opening bank: $openBank DZD", 14f)
                    line("Total expenses: ${expenses.sumOf { it.amount }} DZD", 14f)
                    line("Transactions:", 17f)
                    txs.forEach { tx ->
                        if (y > 790f) return@forEach
                        line("${tx.date} | ${tx.kind} | ${tx.note} | ${tx.amount} DZD", 10f)
                    }
                    doc.finishPage(page)
                    doc.writeTo(output)
                    doc.close()
                }
            }
        }
    }

    val colors = if (dark) darkColorScheme(
        primary = Color(0xFF7FD1B9), onPrimary = Color(0xFF0B2520), secondary = orange,
        background = Color(0xFF101514), surface = Color(0xFF1B2220), primaryContainer = Color(0xFF1F4D44)
    ) else lightColorScheme(
        primary = ink, secondary = orange, background = bg, surface = Color.White, primaryContainer = ink
    )
    CompositionLocalProvider(LocalLayoutDirection provides (if (appLang.value == "en") LayoutDirection.Ltr else LayoutDirection.Rtl)) {
    MaterialTheme(colorScheme = colors) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = { Column { Text("TH Finance", fontWeight = FontWeight.Bold); Text(t("إدارة أموالك بذكاء"), fontSize = 12.sp) } },
                    actions = {
                        TextButton(onClick = {
                            val n = if (appLang.value == "ar") "en" else "ar"
                            appLang.value = n
                            prefs.edit().putString("lang", n).apply()
                        }) { Text(if (appLang.value == "ar") "EN" else "عربي", fontWeight = FontWeight.Bold) }
                        IconButton(onClick = { dark = !dark; prefs.edit().putBoolean("dark", dark).apply() }) {
                            Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, t("الوضع الليلي"))
                        }
                        IconButton(onClick = { tab = 4 }) { Icon(Icons.Default.BarChart, t("الإحصائيات")) }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }, containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary) {
                    Icon(Icons.Default.Add, t("إضافة"))
                }
            },
            bottomBar = {
                NavigationBar {
                    listOf("الرئيسية", "الحركات", "الميزانية", "الديون", "إحصائيات").forEachIndexed { i, label ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i },
                            icon = { Icon(listOf(Icons.Default.Home, Icons.Default.ReceiptLong, Icons.Default.Calculate, Icons.Default.Handshake, Icons.Default.PieChart)[i], null) },
                            label = { Text(t(label), fontSize = 10.sp) })
                    }
                }
            }
        ) { padding ->
            when (tab) {
                0 -> HomeScreen(month, { month = month.minusMonths(1) }, { month = month.plusMonths(1) },
                    cashBalance, bankBalance, totalAvailable, monthIncome, spent, goal.toDoubleOrNull() ?: settings?.savingsGoal ?: 0.0,
                    txs.take(5), onDelete = { id -> scope.launch { dao.delete(id) } }, netSalary = netSalary, absences = ab, carriedTotal = if (autoOpening) carriedCash + carriedBank else null, modifier = Modifier.padding(padding))
                1 -> TransactionsScreen(txs, onDelete = { id -> scope.launch { dao.delete(id) } }, modifier = Modifier.padding(padding))
                2 -> BudgetScreen(salary, { salary = it }, cash, { cash = it }, bank, { bank = it }, goal, { goal = it },
                    workDays = workDays, onWorkDays = { workDays = it }, absences = absences, onAbsences = { absences = it },
                    dailyWage = dailyWage, deduction = deduction, netSalary = netSalary,
                    autoOpening = autoOpening, carriedCash = carriedCash, carriedBank = carriedBank,
                    onSave = { scope.launch { dao.saveSettings(MonthSettings(key, salary.toDoubleOrNull() ?: 0.0, openCash, openBank, goal.toDoubleOrNull() ?: 0.0, ab, wd)) } },
                    modifier = Modifier.padding(padding))
                3 -> DebtsScreen(debts, onDelete = { id -> scope.launch { dao.delete(id) } }, modifier = Modifier.padding(padding))
                else -> StatsScreen(expenses, spent, monthIncome, saved, buildMonthly(allSettings, allTxs), onExport = { pdfLauncher.launch("TH_Finance_$key.pdf") }, modifier = Modifier.padding(padding))
            }
        }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text(t("إضافة حركة مالية")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    var expanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                        OutlinedTextField(value = t(when(kind) { "expense" -> "مصروف / مشتريات"; "bill" -> "فاتورة"; "income" -> "دخل إضافي"; "transfer" -> "تحويل بين الحسابات"; "debt" -> "دين"; else -> "ادخار" }),
                            onValueChange = {}, readOnly = true, label = { Text(t("نوع الحركة")) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            listOf("مصروف / مشتريات" to "expense", "فاتورة" to "bill", "دخل إضافي" to "income", "تحويل بين الحسابات" to "transfer", "دين" to "debt", "ادخار" to "saving").forEach { (l,v) ->
                                DropdownMenuItem(text = { Text(t(l)) }, onClick = { kind = v; category = if(v=="bill") "فواتير" else if(v=="transfer") "من نقدًا" else if(v=="debt") debtType else "مشتريات"; expanded = false })
                            }
                        }
                    }
                    OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text(t(if (kind == "debt") "اسم صاحب الدين / المدين" else "الوصف / الجهة")) }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = amount, onValueChange = { amount = it }, label = { Text(t("المبلغ بالدينار")) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                    if (kind == "transfer") {
                        Text(t("اتجاه التحويل"))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(selected = category == "من نقدًا", onClick = { category = "من نقدًا" }, label = { Text(t("نقدًا ← بنك")) })
                            FilterChip(selected = category == "من البنك", onClick = { category = "من البنك" }, label = { Text(t("بنك ← نقدًا")) })
                        }
                    } else if (kind == "debt") {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(selected = category == "دين عليّ", onClick = { category = "دين عليّ" }, label = { Text(t("دين عليّ")) })
                            FilterChip(selected = category == "لي عند الغير", onClick = { category = "لي عند الغير" }, label = { Text(t("لي عند الغير")) })
                        }
                    }
                    Text(t("الحساب"))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = account == "نقدًا", onClick = { account = "نقدًا" }, label = { Text(t("نقدًا")) })
                        FilterChip(selected = account == "البنك", onClick = { account = "البنك" }, label = { Text(t("البنك")) })
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val v = amount.toDoubleOrNull()
                    if (v != null && v > 0 && !(kind == "debt" && note.isBlank())) {
                        scope.launch {
                            val finalCategory = if (kind == "transfer") category else if(kind=="debt") category else if(kind=="bill") "فواتير" else if(kind=="saving") "ادخار" else if(kind=="income") "دخل إضافي" else "مشتريات"
                            dao.add(Tx(month = key, kind = kind, category = finalCategory, note = note.ifBlank { finalCategory }, amount = v, account = account))
                        }
                        amount = ""; note = ""; showAdd = false
                    }
                }) { Text(t("حفظ")) }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text(t("إلغاء")) } }
        )
    }
    }
    }
}

@Composable
fun Header(text: String) { Text(text, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) }

@Composable
fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Text(title, color = Color.Gray, fontSize = 12.sp)
            Text(value, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
fun HomeScreen(month: YearMonth, prev: () -> Unit, next: () -> Unit, cash: Double, bank: Double, total: Double,
               income: Double, spent: Double, goal: Double, recent: List<Tx>, onDelete: (Long)->Unit, netSalary: Double = 0.0, absences: Int = 0, carriedTotal: Double? = null, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text(t("إجمالي أموالك المتاحة"), color = mint)
                    Text(money(total), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column { Text(t("نقدًا"), color = mint, fontSize = 12.sp); Text(money(cash), color = Color.White, fontWeight = FontWeight.SemiBold) }
                        Column { Text(t("في البنك"), color = mint, fontSize = 12.sp); Text(money(bank), color = Color.White, fontWeight = FontWeight.SemiBold) }
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                IconButton(onClick = prev) { Icon(Icons.Default.ChevronLeft, t("الشهر السابق")) }
                Text(month.toString(), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                IconButton(onClick = next) { Icon(Icons.Default.ChevronRight, t("الشهر التالي")) }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard(t("الدخل الشهري"), money(income), Icons.Default.TrendingUp, Modifier.weight(1f))
                StatCard(t("المصاريف"), money(spent), Icons.Default.TrendingDown, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard(t("الراتب الصافي"), money(netSalary), Icons.Default.Payments, Modifier.weight(1f))
                StatCard(t("أيام الغياب"), "$absences ${t("يوم")}", Icons.Default.EventBusy, Modifier.weight(1f))
            }
        }
        if (carriedTotal != null) {
            item { StatCard(t("المتبقي من الشهر السابق (مُضاف تلقائياً)"), money(carriedTotal), Icons.Default.AccountBalanceWallet, Modifier.fillMaxWidth()) }
        }
        item { Header(t("آخر الحركات")) }
        if (recent.isEmpty()) item { Text(t("لا توجد حركات بعد. اضغط + لإضافة أول حركة."), color = Color.Gray) }
        items(recent) { tx -> TransactionRow(tx, onDelete) }
    }
}

@Composable
fun TransactionRow(tx: Tx, onDelete: (Long)->Unit) {
    if (tx.kind == "debt") { DebtRow(tx, onDelete); return }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tx.note, fontWeight = FontWeight.SemiBold)
                Text("${t(tx.category)} • ${tx.date}", fontSize = 11.sp, color = Color.Gray)
            }
            Text(money(tx.amount), fontWeight = FontWeight.Bold, color = if(tx.kind=="income") Color(0xFF16834D) else MaterialTheme.colorScheme.primary, fontSize = 13.sp)
            IconButton(onClick = { onDelete(tx.id) }) { Icon(Icons.Default.DeleteOutline, null, tint = Color.Gray) }
        }
    }
}

@Composable
fun TransactionsScreen(txs: List<Tx>, onDelete: (Long)->Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), contentPadding = PaddingValues(bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Header(t("سجل الحركات")) }
        if(txs.isEmpty()) item { Text(t("سجل المصاريف والدخل والتحويلات والادخار من زر +")) }
        items(txs) { TransactionRow(it, onDelete) }
    }
}

@Composable
fun BudgetScreen(salary: String, onSalary: (String)->Unit, cash: String, onCash: (String)->Unit, bank: String, onBank: (String)->Unit,
                 goal: String, onGoal: (String)->Unit,
                 workDays: String, onWorkDays: (String)->Unit, absences: String, onAbsences: (String)->Unit,
                 dailyWage: Double, deduction: Double, netSalary: Double,
                 autoOpening: Boolean, carriedCash: Double, carriedBank: Double,
                 onSave: ()->Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), contentPadding = PaddingValues(bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Header(t("الميزانية والأرصدة الافتتاحية")) }
        item { Text(t("أدخل القيم الخاصة بالشهر الحالي. يمكنك تعديلها في أي وقت."), color = Color.Gray, fontSize = 12.sp) }
        item { MoneyField(t("الراتب الشهري"), salary, onSalary) }
        item { MoneyField(t("أيام العمل في الشهر"), workDays, onWorkDays) }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                FilledTonalIconButton(onClick = { onAbsences(((absences.toIntOrNull() ?: 0) - 1).coerceAtLeast(0).toString()) }) { Icon(Icons.Default.Remove, t("نقص")) }
                OutlinedTextField(value = absences, onValueChange = onAbsences, label = { Text(t("عدد أيام الغياب")) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                FilledTonalIconButton(onClick = { onAbsences(((absences.toIntOrNull() ?: 0) + 1).toString()) }) { Icon(Icons.Default.Add, t("زيادة")) }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(t("حساب الراتب"), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text("${t("أجر اليوم")}: ${money(dailyWage)}", fontSize = 13.sp)
                    Text("${t("خصم الغياب")}: ${money(deduction)}", fontSize = 13.sp)
                    Text("${t("الراتب الصافي")}: ${money(netSalary)}", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
        if (autoOpening) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(t("المتبقي من الشهر السابق (يُرحَّل تلقائياً)"), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text("${t("نقدًا")}: ${money(carriedCash)}", fontSize = 13.sp)
                        Text("${t("في البنك")}: ${money(carriedBank)}", fontSize = 13.sp)
                    }
                }
            }
        } else {
            item { MoneyField(t("النقدية الموجودة بداية الشهر"), cash, onCash) }
            item { MoneyField(t("رصيد البنك بداية الشهر"), bank, onBank) }
        }
        item { MoneyField(t("هدف الادخار الشهري"), goal, onGoal) }
        item { Button(onClick = onSave, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text(t("حفظ الميزانية")) } }
    }
}

@Composable
fun MoneyField(label: String, value: String, onChange: (String)->Unit) {
    OutlinedTextField(value = value, onValueChange = onChange, label = { Text(label) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(), singleLine = true)
}

@Composable
fun DebtRow(tx: Tx, onDelete: (Long)->Unit) {
    val owedToOthers = tx.category == "دين عليّ"
    val tone = if (owedToOthers) Color(0xFFC0392B) else Color(0xFF16834D)
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f), shape = RoundedCornerShape(8.dp)) {
                        Text(tx.note, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
                    }
                    Text(tx.date, fontSize = 12.sp, color = Color.Gray)
                }
                Text(t(tx.category), fontSize = 12.sp, color = tone)
            }
            Text(money(tx.amount), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = tone)
            IconButton(onClick = { onDelete(tx.id) }) { Icon(Icons.Default.DeleteOutline, null, tint = Color.Gray) }
        }
    }
}

@Composable
fun DebtsScreen(debts: List<Tx>, onDelete: (Long)->Unit, modifier: Modifier = Modifier) {
    val owed = debts.filter { it.category == "دين عليّ" }.sumOf { it.amount }
    val receivable = debts.filter { it.category == "لي عند الغير" }.sumOf { it.amount }
    val people = debts.groupBy { it.note.trim() }.map { entry ->
        entry.key to (entry.value.filter { it.category == "لي عند الغير" }.sumOf { it.amount } -
            entry.value.filter { it.category == "دين عليّ" }.sumOf { it.amount })
    }
    LazyColumn(modifier.fillMaxSize().padding(16.dp), contentPadding = PaddingValues(bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Header(t("الديون والمستحقات")) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard(t("ديون عليك"), money(owed), Icons.Default.ArrowUpward, Modifier.weight(1f))
            StatCard(t("ديون لك"), money(receivable), Icons.Default.ArrowDownward, Modifier.weight(1f))
        } }
        item { Text(t("أضف دينًا من زر +، واكتب اسم صاحب الدين أو المدين، وحدد هل هو دين عليك أم مبلغ لك عند شخص آخر."), color = Color.Gray, fontSize = 12.sp) }
        if (people.isNotEmpty()) {
            item { Header(t("حسب الشخص")) }
            items(people) { person ->
                val net = person.second
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(person.first, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text(
                            if (net > 0) "${t("لك")} ${money(net)}" else if (net < 0) "${t("عليك")} ${money(-net)}" else t("مسدّد"),
                            fontWeight = FontWeight.Bold, fontSize = 13.sp,
                            color = if (net > 0) Color(0xFF16834D) else if (net < 0) Color(0xFFC0392B) else Color.Gray
                        )
                    }
                }
            }
            item { Header(t("سجل الديون")) }
        }
        items(debts) { DebtRow(it, onDelete) }
    }
}

@Composable
fun StatsScreen(expenses: List<Tx>, spent: Double, income: Double, saved: Double, monthly: List<MonthRow>, onExport: () -> Unit, modifier: Modifier = Modifier) {
    val purchases = expenses.filter { it.category == "مشتريات" }.sumOf { it.amount }
    val bills = expenses.filter { it.category == "فواتير" }.sumOf { it.amount }
    val primaryC = MaterialTheme.colorScheme.primary
    LazyColumn(modifier.fillMaxSize().padding(16.dp), contentPadding = PaddingValues(bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Header(t("الإحصائيات الشهرية")) }
        item { OutlinedButton(onClick = onExport, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.width(8.dp)); Text(t("تصدير تقرير PDF")) } }
        item { StatCard(t("إجمالي المصاريف"), money(spent), Icons.Default.Receipt, Modifier.fillMaxWidth()) }
        item { StatCard(t("الدخل"), money(income), Icons.Default.AccountBalance, Modifier.fillMaxWidth()) }
        item { StatCard(t("الادخار المسجل"), money(saved), Icons.Default.Savings, Modifier.fillMaxWidth()) }
        item { Header(t("توزيع المصاريف")) }
        item {
            if(spent <= 0) Text(t("أضف مصاريف لعرض الرسم البياني."), color = Color.Gray)
            else {
                Canvas(Modifier.fillMaxWidth().height(190.dp)) {
                    val total = (purchases + bills).coerceAtLeast(1.0)
                    val p = purchases / total
                    drawArc(primaryC, -90f, (360f*p).toFloat(), false, style = Stroke(width = 34.dp.toPx()))
                    drawArc(orange, -90f + (360f*p).toFloat(), (360f*(1-p)).toFloat(), false, style = Stroke(width = 34.dp.toPx()))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    Text("● ${t("مشتريات")} ${money(purchases)}", color = primaryC, fontSize = 12.sp)
                    Text("● ${t("فواتير")} ${money(bills)}", color = orange, fontSize = 12.sp)
                }
            }
        }
        item { Header(t("حركة الأموال الشهرية")) }
        if (monthly.isEmpty()) item { Text(t("لا توجد بيانات شهرية بعد. احفظ الميزانية أولاً."), color = Color.Gray, fontSize = 12.sp) }
        items(monthly) { r ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(r.month, fontWeight = FontWeight.Bold)
                        Text("${t("رصيد النهاية")}: ${money(r.closeTotal)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                    }
                    Text("${t("رصيد البداية")}: ${money(r.openTotal)}", fontSize = 12.sp, color = Color.Gray)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${t("الدخل")}: ${money(r.income)}", fontSize = 12.sp, color = Color(0xFF16834D))
                        Text("${t("المصاريف")}: ${money(r.spent)}", fontSize = 12.sp, color = Color(0xFFC0392B))
                    }
                    Text("${t("الادخار")}: ${money(r.saved)}", fontSize = 12.sp, color = Color.Gray)
                }
            }
        }
    }
}
